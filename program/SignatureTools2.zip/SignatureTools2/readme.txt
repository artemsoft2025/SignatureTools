 
ArtemSoft SignatureTools v2.0
=============================

Набор утилит для анализа и поиска вредоносного ПО

sigmaker.exe - для создания сигнатур.

siggen.exe - другая программа для создания сигнатур (на выбор, какая больше понравится).

sighunter.exe - сканер для поиска зловредов по созданным сигнатурам.


АВТОРСКИЕ ПРАВА:
(c) 2025 ArtemSoft
Лицензия: FREE License

КОНТАКТЫ:
Telegram: https://t.me/avhelpnew
Email: artemsoft@yahoo.com

ПОДДЕРЖКА:
По вопросам работы утилит обращайтесь в Telegram
Сообщения об ошибках и предложения: artemsoft@yahoo.com
